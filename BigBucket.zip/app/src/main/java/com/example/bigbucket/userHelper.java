package com.example.bigbucket;

public class userHelper {
    String name, email, password;

    public userHelper(String name, String email, String password) {
        this.name = name;
        this.email = email;
        this.password = password;
    }
}
